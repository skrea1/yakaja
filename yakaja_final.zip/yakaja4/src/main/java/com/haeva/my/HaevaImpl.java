package com.haeva.my;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface HaevaImpl {
	
	public void haeva(HttpServletRequest request, HttpServletResponse response) throws Exception;
		
		
		
}
